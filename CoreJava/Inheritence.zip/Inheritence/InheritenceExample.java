package Inheritence;
class Student extends Person{
	void display(){
		//super(2,"Kavita");Error
		System.out.println(getId());
		System.out.println(getName());
	}
	Student(){
		
		super(2,"Kavita");
		System.out.println();
		//Error super(2,"Kavita");
	}
}
public class InheritenceExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Student obj=new Student();
			obj.display();
	}

}
