package Inheritence;
class Employee{
	String name;
	Address adr;//refernce object
	public Employee(String name, Address adr) {
		super();
		this.name = name;
		this.adr = adr;
	}
	void display(){
		System.out.println(name);
		adr.show();
	}
}
public class HASAExample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Address address=new Address(23, "Delhi");
		Employee e1=new Employee("Kavita", address);
		e1.display();

	}

}
