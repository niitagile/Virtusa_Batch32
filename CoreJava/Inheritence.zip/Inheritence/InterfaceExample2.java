package Inheritence;
interface interface3{
	void show();
	default void defaultMethod(){
		System.out.println("default Method");
	}
	static void staticMethod(){
		System.out.println("static method");
	}
	/*Jdk 1.9 onwards
	 * private void privateMethod(){
		System.out.println("private method");
	}*/
}
interface interface4{
	default void defaultMethod(){
		System.out.println("default interface4 Method");
	}
}

class child_intro implements interface3,interface4{

	@Override
	public void show() {
		// TODO Auto-generated method stub
		System.out.println("Hello");
		//super.defaultMethod(); super can be used with classes only
		interface4.super.defaultMethod();
		interface3.staticMethod();
	}
	
}
public class InterfaceExample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		child_intro ch=new child_intro();
		ch.show();
	}

}
