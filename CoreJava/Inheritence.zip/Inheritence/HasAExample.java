package Inheritence;
class TextEditor{
	SpellChecker sp;
	TextEditor(SpellChecker sp){
		this.sp=sp;
	}
	void show(){
		sp.display();
	}
}
public class HasAExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			SpellChecker sp=new SpellChecker();
			TextEditor txt=new TextEditor(sp);
			txt.show();
	}

}
