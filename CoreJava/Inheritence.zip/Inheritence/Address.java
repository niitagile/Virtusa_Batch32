package Inheritence;

public class Address {
	int houseno;
	String city;
	public Address(int housno, String city) {
		super();
		this.houseno = housno;
		this.city = city;
	}
	public void show(){
		System.out.println(houseno +" "+city);
	}

}
