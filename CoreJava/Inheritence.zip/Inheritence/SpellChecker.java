package Inheritence;

public class SpellChecker {
	void display(){
		System.out.println("SpellChecking going on");
	}

}
