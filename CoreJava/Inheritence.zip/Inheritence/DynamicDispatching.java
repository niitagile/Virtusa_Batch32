package Inheritence;
class A{
	int age=45;
	void show(){
		System.out.println("A's Method"+45);
	}
	
}
class B extends A{
	int age=60;
	@Override
	void show(){
		System.out.println("B's Method"+age);
		//super.show();
	}
	void display(){
		System.out.println("Display Method");
	}
}

public class DynamicDispatching {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			A obj=new B();
			
			//obj.display(); error
			obj.age=100;
			obj.show();
			/*obj	=new A();
			obj.show();*/
	}

}
