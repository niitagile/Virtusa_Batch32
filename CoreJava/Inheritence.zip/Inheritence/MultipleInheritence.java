package Inheritence;
interface interface1{
	int a=100;
	void show();
}
/*interface interface1{
 * public static final int a=100;
 * public abstract void show();
 * }
 * 
 * 
 * 
 */
interface interface2{
	void show();
}
class child implements interface1, interface2{

	@Override
	public void show() {
		// TODO Auto-generated method stub
		System.out.println("Hello");
	}
	
}

public class MultipleInheritence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			child ch=new child();
			ch.show();
			//interface1 obj=new child();
			
			
	}

}
