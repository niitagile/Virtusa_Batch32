package Design_pattern;

public class FrontControllerPattern {

}
