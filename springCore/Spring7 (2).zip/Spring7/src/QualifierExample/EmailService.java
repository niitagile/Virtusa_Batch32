package QualifierExample;

public class EmailService implements MessageService {

	@Override
	public void sendMsg(String message) {
		// TODO Auto-generated method stub
		System.out.println(message);
	}

}
