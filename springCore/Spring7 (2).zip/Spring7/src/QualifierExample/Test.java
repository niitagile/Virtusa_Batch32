package QualifierExample;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
  import org.springframework.beans.annotation.*;
public class Test {  
public static void main(String[] args) {  
   
	ApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfiguration.class);
	System.out.println(context);
	MessageProcessor obj = (MessageProcessor)context.getBean(MessageProcessor.class);
	System.out.println(obj);
	obj.processMsg("twitter message is sending...");
	
	
	
}  
}  